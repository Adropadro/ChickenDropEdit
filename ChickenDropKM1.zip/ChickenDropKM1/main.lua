--game where animals fall from top player clicks
--before hit the bottom
--game ends when animal hits bottom

function love.load()
 
  -- Loading Variables
    score = 0

   -- Double Points variables
    doublePointsActive = false
    doublePointsTimer = 0
    doublePointSpawned = false

  
  -- Arrow load
  arrow = love.graphics.newImage("Arrow.png")
  -- Background Load
  backgroundImage = love.graphics.newImage("bg.png")
  -- 2X Points for the player
  powerUpDoublePoints = love.graphics.newImage("2X-PNG.png")

 


  -- Random library
  math.randomseed(os.time())
  -- Extra random
  math.random(); math.random(); math.random()
  
  -- Random starting points
  startx = {math.random(0, love.graphics.getWidth() - arrow:getWidth()), 
            math.random(0, love.graphics.getWidth() - arrow:getWidth()),  
            math.random(0, love.graphics.getWidth() - arrow:getWidth()),  
            math.random(0, love.graphics.getWidth() - arrow:getWidth()), 
            math.random(0, love.graphics.getWidth() - arrow:getWidth())}
    
  starty = {0 - math.random(arrow:getHeight(), arrow:getHeight() * 2),
            0 - math.random(arrow:getHeight(), arrow:getHeight() * 2),
            0 - math.random(arrow:getHeight(), arrow:getHeight() * 2),
            0 - math.random(arrow:getHeight(), arrow:getHeight() * 2),
            0 - math.random(arrow:getHeight(), arrow:getHeight() * 2)}
  
  --Double pionts x
  doublePointsX = math.random(0, love.graphics.getWidth() - powerUpDoublePoints:getWidth())
  
  --double points y
  doublePointsY = -math.random(powerUpDoublePoints:getHeight(), powerUpDoublePoints:getHeight() * 2)

end



-------------------------------------------------
--MOUSE PRESS
--1 = left, 2 = right, 3 = middle wheel
-------------------------------------------------
function love.mousepressed(x, y, button, istouch)
  if button == 1 then
    --print("left mouse clicked")
    for i, v in ipairs(startx) do
      
      -- If the mouse x and y is within the boundary of a ARROW picture
      if x >= startx[i] and x <= startx[i] + arrow:getWidth() and y >= starty[i] and y <= starty[i] + arrow:getHeight() then

        -- Doubling the points when we click 2X img
       if doublePointsActive then
          score = score + 2
        else 
          score = score + 1
        end
          
        --print("in bounds")
        math.randomseed(os.time())
        math.random(); math.random(); math.random()

        -- Reset its y value and changing the X. Going back to the top. 
        starty[i] = math.random(arrow:getHeight(), arrow:getHeight() * 2) * -1
        startx[i] = math.random(0, love.graphics.getWidth() - arrow:getWidth())
      end
      
    end
  end
  
  -- Check if player clicked on the power-up 
  if doublePointSpawned and
     x >= doublePointsX and x <= doublePointsX + powerUpDoublePoints:getWidth() and
     y >= doublePointsY and y <= doublePointsY + powerUpDoublePoints:getHeight() then
    doublePointsActive = true
    doublePointsTimer = 5

    -- Reset power-up position (make it fall again later)
    doublePointsY = -math.random(powerUpDoublePoints:getHeight(), powerUpDoublePoints:getHeight() * 2)
    doublePointsX = math.random(0, love.graphics.getWidth() - powerUpDoublePoints:getWidth())
    doublePointSpawned = false -- hides it until you want it again
  end



  
end




-------------------------------------------------
--UPDATE
-------------------------------------------------
function love.update(dt)

  
  for i, v in ipairs(starty) do
    -- If chicken hits the bottom of the screen lua will quit the program and lose the game.
    if starty[i] + arrow:getHeight() >= love.graphics.getHeight() then
      --print("over the edge")
      love.event.quit()
    end
    -- Chickens are moving down. 
    starty[i] = starty[i] + 80 * dt
  end

  -- Doing a timer for the double points
  if doublePointsActive then
    doublePointsTimer = doublePointsTimer - dt
    if doublePointsTimer <= 0 then
      doublePointsActive = false
    end
  end

  -- Spawning the 2x
  if score == 6 then
    doublePointSpawned = true
    doublePointsX = math.random(0, love.graphics.getWidth() - powerUpDoublePoints:getWidth())
    doublePointsY = -math.random(powerUpDoublePoints:getHeight(), powerUpDoublePoints:getHeight() * 2)
    print("2X Power-Up Spawned!")
  end
  
  -- If the 2x spawned then move it dow
  if doublePointSpawned then
    doublePointsY = doublePointsY + 80 * dt
  end
  
  
end




-------------------------------------------------
--DRAW
-------------------------------------------------
function love.draw()
  
  --Background
  love.graphics.draw(backgroundImage, 0, 0)
  
  -- Printing the score
  love.graphics.print("Score: " .. score, 10, 10)
  
  -- Draw each chicken at their respective x and y
  for i, v in ipairs(startx) do  
    love.graphics.draw(arrow, startx[i], starty[i])
  end

  -- Drawing the 2X
  if doublePointSpawned then
    love.graphics.draw(powerUpDoublePoints, doublePointsX, doublePointsY)
  end
  
end